package com.example.cobaproyek2.ui.settings

import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Switch
import android.widget.Toast

import com.example.cobaproyek2.R
import kotlinx.android.synthetic.main.settings_fragment.*

class SettingsFragment : Fragment() {

    val sharedPrefAlarmName = "AlarmPref"
    val keyDataAlarm = "AlarmNotif"

    val sharedPrefNotifName = "NotifPref"
    val keyDataNotif = "PushNotif"

    lateinit var sharedPrefAlarm: SharedPreferences
    lateinit var sharedPrefNotif: SharedPreferences

    var alarmPreference: Int = 1
    var notifPreference: Int = 0

//    companion object {
//        fun newInstance() = SettingsFragment()
//    }

//    private lateinit var viewModel: SettingsViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.settings_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
//        viewModel = ViewModelProviders.of(this).get(SettingsViewModel::class.java)
        // TODO: Use the ViewModel
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val switchNotif: Switch = requireView().findViewById(R.id.swPushNotif)
        val switchAlarm: Switch = requireView().findViewById(R.id.swAlarmNotif)


//        if(!this.requireContext().getSharedPreferences(sharedPrefAlarmName, Context.MODE_PRIVATE).contains(keyDataAlarm)){
//            sharedPrefAlarm = this.requireContext().getSharedPreferences(sharedPrefAlarmName, Context.MODE_PRIVATE)
//            val editorAlarm: SharedPreferences.Editor = sharedPrefAlarm.edit()
//            Log.d("Switch Alarm Pref", alarmPreference.toString())
//            editorAlarm.putString(keyDataAlarm, alarmPreference.toString())
//            editorAlarm.apply()
//            switchAlarm.isChecked = if(sharedPrefAlarm.getString(keyDataAlarm, null) == "1") true else false
//
//
////            Toast.makeText(this.requireContext(), sharedPrefAlarm.getString(keyDataAlarm, null), Toast.LENGTH_LONG).show()
//        }
//
//        if(!this.requireContext().getSharedPreferences(sharedPrefNotifName, Context.MODE_PRIVATE).contains(keyDataNotif)){
//            sharedPrefNotif = this.requireContext().getSharedPreferences(sharedPrefNotifName, Context.MODE_PRIVATE)
//            val editorNotif: SharedPreferences.Editor = sharedPrefNotif.edit()
//            Log.d("Switch Notif Pref", notifPreference.toString())
//            editorNotif.putString(keyDataNotif, notifPreference.toString())
//            editorNotif.apply()
//        }

        if(this.requireContext().getSharedPreferences(sharedPrefNotifName, Context.MODE_PRIVATE).contains(keyDataNotif)){
            sharedPrefNotif = this.requireContext().getSharedPreferences(sharedPrefNotifName, Context.MODE_PRIVATE)
            notifPreference = sharedPrefNotif.getString(keyDataNotif,null).toString().toInt()
            switchNotif.isChecked = if(sharedPrefNotif.getString(keyDataNotif, null) == "1") true else false
        }

        if(this.requireContext().getSharedPreferences(sharedPrefAlarmName, Context.MODE_PRIVATE).contains(keyDataAlarm)){
            sharedPrefAlarm = this.requireContext().getSharedPreferences(sharedPrefAlarmName, Context.MODE_PRIVATE)
            alarmPreference = sharedPrefAlarm.getString(keyDataAlarm, null).toString().toInt()
            switchAlarm.isChecked = if(sharedPrefAlarm.getString(keyDataAlarm, null) == "1") true else false
        }



        switchAlarm.setOnCheckedChangeListener { buttonView, isChecked ->
            if(switchAlarm.isChecked) {
                Log.d("Switch Alarm", "On")
                alarmPreference = 1
            } else{
                Log.d("Switch Alarm", "Off")
                alarmPreference = 0
            }
        }

        switchNotif.setOnCheckedChangeListener { buttonView, isChecked ->
            if(switchNotif.isChecked) {
                Log.d("Switch Notif", "On")
                notifPreference = 1
            } else{
                Log.d("Switch Notif", "Off")
                notifPreference = 0
            }
        }

        btnSaveSetting.setOnClickListener {
            if(notifPreference == 0 && alarmPreference == 0){
                Toast.makeText(this.requireContext(), "Harap Pilih Minimal Satu", Toast.LENGTH_LONG).show()
            }
            else{
                if(this.requireContext().getSharedPreferences(sharedPrefAlarmName, Context.MODE_PRIVATE).contains(keyDataAlarm)){
                    sharedPrefAlarm = this.requireContext().getSharedPreferences(sharedPrefAlarmName, Context.MODE_PRIVATE)
                    val editorAlarm: SharedPreferences.Editor = sharedPrefAlarm.edit()
                    Log.d("Switch Alarm Pref", alarmPreference.toString())
                    editorAlarm.putString(keyDataAlarm, alarmPreference.toString())
                    editorAlarm.apply()
                }

                if(this.requireContext().getSharedPreferences(sharedPrefNotifName, Context.MODE_PRIVATE).contains(keyDataNotif)){
                    sharedPrefNotif = this.requireContext().getSharedPreferences(sharedPrefNotifName, Context.MODE_PRIVATE)
                    val editorNotif: SharedPreferences.Editor = sharedPrefNotif.edit()
                    Log.d("Switch Alarm Pref", alarmPreference.toString())
                    editorNotif.putString(keyDataNotif, notifPreference.toString())
                    editorNotif.apply()
                }

                Toast.makeText(this.requireContext(), "Setting Disimpan", Toast.LENGTH_LONG).show()

                Log.d("Pref", sharedPrefAlarm.getString(keyDataAlarm, null).toString())
                Log.d("Pref", sharedPrefNotif.getString(keyDataNotif, null).toString())
//                Log.d("Pref", this.requireContext().getSharedPreferences(sharedPrefAlarmName, Context.MODE_PRIVATE).toString())

            }
            Log.d("Switch", "Alarm: $alarmPreference Notif: $notifPreference")
        }
    }
}
