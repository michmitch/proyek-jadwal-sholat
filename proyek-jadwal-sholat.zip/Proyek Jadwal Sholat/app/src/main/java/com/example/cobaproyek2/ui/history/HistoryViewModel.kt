package com.example.cobaproyek2.ui.history

import androidx.lifecycle.ViewModel

class HistoryViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
