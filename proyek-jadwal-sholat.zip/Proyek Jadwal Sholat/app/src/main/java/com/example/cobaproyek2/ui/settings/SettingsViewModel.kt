package com.example.cobaproyek2.ui.settings

import androidx.lifecycle.ViewModel

class SettingsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
